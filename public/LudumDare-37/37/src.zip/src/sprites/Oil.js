import Phaser from 'phaser';
import InventoryItem from '../sprites/InventoryItem';

let towelState = {
  OIL:0,
  OILYBEARD:1
}

export default class extends InventoryItem {

  constructor (game) {

    let x = 70;
    let y = 158;
    let asset = 'oil';
    let position = new Phaser.Point(96,155);

    super(game, x, y, asset,position);
    this.name = "OIL";
    this.iconName = "oilIcon";

    this.game.add.existing(this);
    this.anchor.set(0.5,1);

    this.pickUp();

    this.currentState = towelState.OIL;

  }

  inspect()
  {
    if(this.currentState == towelState.OIL)
    {
      return "Elbow Grease branded grease.";
    }
    else {
      return "A greasy santa beard, nothing finer.";
    }
  }

  pickUp()
  {
    this.visible = false;
  }

  canCombineWith(item)
  {
    if(item.name === "TOWEL")
    {
      this.name = "OILRAG";
      this.currentState = towelState.OILYBEARD;
      this.iconName = "oilyBeardIcon";
      return true;
    }
    else {
      return false;
    }
  }

  useItem()
  {
    console.log("USING ITEM -------- OIL");
    if(isStartingFuture())
    {
      this.name = "OILRAG";
      this.currentState = towelState.OILYBEARD;
      this.iconName = "oilyBeardIcon";
    }
  }

  messageRecieved(data)
  {
    super.messageRecieved(data);
  }


}
