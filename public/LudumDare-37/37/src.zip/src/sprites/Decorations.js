import Phaser from 'phaser';
import InventoryItem from '../sprites/InventoryItem';

export default class extends InventoryItem {

  constructor (game) {

    let x = 44;
    let y = 220;
    let asset = 'decorationsEmpty';
    let position = new Phaser.Point(105,215);

    super(game, x, y, asset,position);
    this.name = "DECORATIONS";
    this.iconName = "decorationsIcon";
    this.game.add.existing(this);
    this.anchor.set(0.5,1);


    this.pickUp();
    this.input.enabled = false;

    if(isStartingFuture())
    {

    }
  }

  inspect()
  {
      return "A twinkly set of lights.\nJust what I need for my tree.";
  }

  pickUp()
  {
    this.visible = false;
  }

  canPickUp()
  {
      return true;
  }

  messageRecieved(data)
  {
    super.messageRecieved(data);
  }


}
