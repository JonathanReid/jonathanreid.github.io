import Phaser from 'phaser'
import GameServices from '../boot/GameServices';

export default class extends Phaser.Sprite {

  constructor ({ game, x, y, asset }) {
    super(game, x, y, asset)

    this.game = game
    this.anchor.setTo(0.5);

    this.currentAnim = "walk";
    this.stopFrame = 0;

    let frames = [0,1,2];
    this.animations.add("walk",frames);
    frames = [3,4,5];
    this.animations.add("beard",frames);
    frames = [6,7,8];
    this.animations.add("oilyBeard",frames);

  }

  update () {
    // this.angle += 1
  }

  move()
  {
    this.animations.play(this.currentAnim, 18, true);
    GameServices.Sound.playSound("sndWalk","", 0, 0.2, true);
  }

  stop()
  {
    this.animations.stop();
    this.frame = this.stopFrame;
    GameServices.Sound.stopSound("sndWalk");
  }

  wearBeard()
  {
    this.currentAnim = "beard";
    this.frame = 3;
    this.stopFrame = 3;
  }

  wearOilyBeard()
  {
    this.currentAnim = "oilyBeard";
    this.frame = 6;
    this.stopFrame = 6;
  }

  takeOffBeard()
  {
    this.currentAnim = "walk";
    this.stopFrame = 0;
  }

}
