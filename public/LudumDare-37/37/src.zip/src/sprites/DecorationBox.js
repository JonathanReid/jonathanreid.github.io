import Phaser from 'phaser';
import InteractiveObject from '../sprites/InteractiveObject';

let boxStates = {
    LOCKED: 0,
    UNLOCKED:1,
    EMPTY:2,
}

export default class extends InteractiveObject {

  constructor (game) {

    let x = 44;
    let y = 220;
    let asset = 'decorationsTaped';
    let position = new Phaser.Point(105,215);

    super(game, x, y, asset,position);

    this.game.add.existing(this);
    this.anchor.set(0.5,1);

    this.currentState = boxStates.LOCKED;

    if(isStartingFuture())
    {
      this.currentState = boxStates.EMPTY;
      this.loadTexture("decorationsEmpty");
    }
  }

  inspect()
  {
    if(this.currentState == boxStates.LOCKED)
    {
      return "This is all taped up.\nI cant open this with my bear hands.";
    }
    else if(this.currentState == boxStates.UNLOCKED)
    {
      return "A twinkly set of lights.\nJust what I need for my tree.";
    }
    else if(this.currentState == boxStates.EMPTY)
    {
      return "Empty. Like my life.";
    }
  }

  itemsRetrievedOnInspect()
  {
    if(this.currentState == boxStates.UNLOCKED)
    {
      let items = [];
      items.push("DECORATIONS");
      this.currentState = boxStates.EMPTY;
      this.loadTexture("decorationsEmpty");
      return items;
    }
    else {
      return [];
    }
  }

  canUseItem(item)
  {
    if(item !== undefined)
    {
      if(item.name === "KNIFE")
      {
        return true;
      }
      else {
        return false;
      }
    }
    else
    {
      return false;
    }
  }

  incorrectItemText(item)
  {
    if(item !== undefined)
    {
      return "I'm not sure thats right";
    }
  }

  correctItemText(item)
  {
    if(item !== undefined)
    {

      if(item.name === "KNIFE")
      {
        return "With a swift slice, I almost cut my thumb off.\nBut the box is open now";
      }
    }
  }

  useItemOn(item)
  {
    if(item !== undefined)
    {
      if(item.name === "KNIFE")
      {
        this.unlocked();
        item.used();
      }
    }
  }

  unlocked()
  {
    this.currentState = boxStates.UNLOCKED;

    this.setOpened();
    if(!isStartingFuture())
    {
      sendData("DECORATIONS_UNLOCKED");
    }
  }

  setOpened()
  {
    this.loadTexture("decorations");
  }

  messageRecieved(data)
  {
    super.messageRecieved(data);
    if(isStartingFuture())
    {
      if(data == "DECORATIONS_UNLOCKED")
      {
        // this.currentState = boxStates.UNLOCKED;
      }
    }
  }

}
