import Phaser from 'phaser';
import InventoryItem from '../sprites/InventoryItem';

export default class extends InventoryItem {

  constructor (game) {

    let x = 70;
    let y = 158;
    let asset = 'baubel';
    let position = new Phaser.Point(96,155);

    super(game, x, y, asset,position);
    this.name = "BAUBEL";
    this.iconName = "baubelIcon";

    this.game.add.existing(this);
    this.anchor.set(0.5,1);

    if(isStartingFuture())
    {
      this.pickUp();
    }

  }

  inspect()
  {
    return "A decorative baubel. Has the face of pope francis delicately painted on it.";
  }

  pickUp()
  {
    this.visible = false;
  }

  messageRecieved(data)
  {
    super.messageRecieved(data);
  }


}
