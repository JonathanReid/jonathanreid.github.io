import Phaser from 'phaser'

export default class extends Phaser.Sprite {

  constructor (game, x, y, asset, position) {

    super(game, x, y, asset)
    this.clicked = new Phaser.Signal();

    this.characterPosition = position;
    this.game = game;

    this.inputEnabled = true;
    this.events.onInputDown.add(this.objectClicked, this);

    let context = this;
    this.messageRecievedEvent = function (e) {
      context.messageRecieved(e.detail);
    };
    document.addEventListener('gameMessage', this.messageRecievedEvent);
  }

  showCode()
  {
    return false;
  }

  itemsRetrievedOnInspect()
  {
    return [];
  }

  objectClicked()
  {
    this.clicked.dispatch(this);
  }

  messageRecieved(data)
  {

  }

  destroy()
  {
    super.destroy();
    document.removeEventListener('gameMessage', this.messageRecievedEvent);
  }

}
