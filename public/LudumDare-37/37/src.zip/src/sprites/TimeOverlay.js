import Phaser from 'phaser'

export default class extends Phaser.Sprite {

  constructor (game) {



    super(game, 0, 0, "blackPixel");

    this.game = game;

    this.scale.set(this.game.world.width,this.game.world.height);
    this.visible = false;

    this.game.add.existing(this);

    this.text = this.game.add.bitmapText(this.game.world.centerX, this.game.world.centerY, 'pixelFont',"15 MINUTES EARLIER",30);
    this.text.tint = "0xFFFFFF";
    this.text.anchor.set(0.5);
    this.text.visible = false;
  }

  forceShow()
  {
    this.visible = true;
  }

  show(showText,callback,context)
  {
    this.visible = true;
    this.game.add.tween(this).to( { alpha: 0 }, 2000, Phaser.Easing.Quadratic.InOut, true, 2000).onComplete.add(callback,context);
    if(showText)
    {
      this.text.visible = true;
    }
    else {
      this.text.visible = false;
    }
    this.game.add.tween(this.text).to( { alpha: 0 }, 2000, Phaser.Easing.Quadratic.InOut, true,2000);
  }

  hide(callback,context)
  {
    this.visible = true;
    this.alpha = 0;
    this.game.add.tween(this).to( { alpha: 1 }, 2000, Phaser.Easing.Quadratic.InOut, true).onComplete.add(callback,context);
  }

}
