import Phaser from 'phaser';
import InventoryItem from '../sprites/InventoryItem';

let towelState = {
  BEARD:0,
  OILYBEARD:1
}

export default class extends InventoryItem {

  constructor (game) {

    let x = 370;
    let y = 228;
    let asset = 'beard';
    let position = new Phaser.Point(316,226);

    super(game, x, y, asset,position);
    this.name = "TOWEL";
    this.iconName = "beardIcon";

    this.game.add.existing(this);
    this.anchor.set(0.5,1);

    this.currentState = towelState.BEARD;

      // this.pickUp();

      if(isStartingFuture())
      {
        this.pickUp();
      }
  }

  inspect()
  {
    if(this.currentState == towelState.BEARD)
    {
      return "Its one of those fake santa beards.";
    }
    else {
      return "Its a santa beard caked in oil.";
    }
  }

  pickUp()
  {
    this.visible = false;
  }

  canCombineWith(item)
  {
    if(item !== undefined)
    {
      if(item.name === "OIL")
      {
        this.name = "OILRAG";
        this.currentState = towelState.OILYBEARD;
        this.iconName = "oilyBeardIcon";
        return true;
      }
      else {
        return false;
      }
    }
  }

  useItem()
  {
    // super.useItem();
    console.log("USING ITEM -------- TOWEL");
    if(isStartingFuture())
    {
      this.name = "OILRAG";
      this.currentState = towelState.OILYBEARD;
      this.iconName = "oilyBeardIcon";
    }
  }

  messageRecieved(data)
  {
    super.messageRecieved(data);
  }


}
