import Phaser from 'phaser';
import InventoryItem from '../sprites/InventoryItem';

export default class extends InventoryItem {

  constructor (game) {

    let x = 67;
    let y = 151;
    let asset = 'key';
    let position = new Phaser.Point(96,155);

    super(game, x, y, asset,position);
    this.name = "KEY";
    this.iconName = "keyIcon";

    this.game.add.existing(this);
    this.anchor.set(0.5,1);

    if(isStartingFuture())
    {
      this.pickUp();
    }
  }

  inspect()
  {
    return "My keys! Been looking for these for days";
  }

  pickUp()
  {
    this.visible = false;
  }

  messageRecieved(data)
  {
    super.messageRecieved(data);
  }


}
