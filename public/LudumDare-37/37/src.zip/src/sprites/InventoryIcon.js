import Phaser from 'phaser'

export default class extends Phaser.Sprite {

  constructor (game, x, y, asset) {

    super(game, (x*60)+110, y, asset)
    this.clicked = new Phaser.Signal();
    this.game = game;

    this.game.add.existing(this);

    this.inputEnabled = true;
    this.events.onInputDown.add(this.objectClicked, this);
    this.activeItem = undefined;
  }

  objectClicked()
  {
    this.clicked.dispatch(this);
    // this.selectItem();
  }

  setItem(item)
  {
    this.activeItem = item;
    this.changeIcon();
  }

  getItem()
  {
    return this.activeItem;
  }

  changeIcon()
  {
    this.loadTexture(this.activeItem.iconName, 0);
    this.visible = true;
  }

  selectItem()
  {
    if(this.activeItem !== undefined)
    {
      this.tint = "0xFF33ff";
    }
  }

  deselectItem()
  {
    this.tint = "0xFFFFFF";
  }

  combine(item)
  {
    if(this.activeItem !== undefined)
    {
      if(this.activeItem.canCombineWith(item.activeItem))
      {
        this.changeIcon();
        return true;
      }
    }
    return false;
  }

  useItem()
  {
    if(this.activeItem.used)
    {
      if(!isStartingFuture())
      {
        sendData("USED_ITEM_"+this.activeItem.name);
      }
      else {
        this.activeItem.useItem();
      }
      this.activeItem = undefined;
      this.loadTexture("emptyIconSlot");
    }
    // this.visible = false;
  }

}
