import Phaser from 'phaser';
import InteractiveObject from '../sprites/InteractiveObject';

let windowStates = {
    OPEN: 0,
    CLOSED:1
}

export default class extends InteractiveObject {

  constructor (game) {

    let x = 252;
    let y = 58;
    let asset = 'window';
    let position = new Phaser.Point(253,183);

    super(game, x, y, asset,position);

    let frames = [0,1,2];
    this.animations.add("close",frames);

    this.game.add.existing(this);
    this.anchor.set(0.5,0.5);

    this.currentState = windowStates.OPEN;

  }

  inspect()
  {
    if(this.currentState === windowStates.OPEN)
    {
      return "My window has been stuck open all day."
    }
    else if(this.currentState === windowStates.CLOSED)
    {
      return "It could do with a wash.";
    }
  }

  canUseItem(item)
  {
    if(item !== undefined)
    {
      if(this.currentState === windowStates.OPEN)
      {
        if(item.name === "OILRAG")
        {
          return true;
        }
        else
        {
          return false;
        }
      }
      else {
        return false;
      }
    }
    else
    {
      return false;
    }
  }

  incorrectItemText(item)
  {
    if(item !== undefined)
    {
      if(item.name === "KEY")
      {
        return "It's already wide open. Thats kinda my problem";
      }
      if(item.name === "BAUBEL")
      {
        return "That neighbor kid really does annoy me, but I'm not throwing my baubels at him";
      }
      if(item.name === "TOWEL")
      {
        return "You want me to what on WHERE?";
      }
      if(item.name === "OIL")
      {
        return "Thats no way to apply oil!\nYou need a rag of some kind";
      }
      return "I'm not sure thats right";
    }
  }

  correctItemText(item)
  {
    if(item !== undefined)
    {
      if(item.name === "OILRAG")
      {
        return "Thats one sticky window pane in my arse.\nheh heh.";
      }

    }
  }

  useItemOn(item)
  {
    if(item !== undefined)
    {
      console.log("using " + item + " on window" );
      if(item.name === "OILRAG")
      {
        this.currentState = windowStates.CLOSED;
        sendData("WINDOW_CLOSED");
        this.closeWindow();
      }
    }
  }

  isOpen()
  {
    return this.currentState == windowStates.OPEN;
  }

  closeWindow()
  {
    this.animations.play("close", 18, false);
  }

  messageRecieved(data)
  {
    super.messageRecieved(data);
    if(data === "WINDOW_CLOSED")
    {
      this.currentState = windowStates.CLOSED;
      this.frame = 2;
    }
  }

}
