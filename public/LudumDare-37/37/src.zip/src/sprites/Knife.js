import Phaser from 'phaser';
import InventoryItem from '../sprites/InventoryItem';

export default class extends InventoryItem {

  constructor (game) {

    let x = 289;
    let y = 159;
    let asset = 'knife';
    let position = new Phaser.Point(272,194);

    super(game, x, y, asset,position);
    this.name = "KNIFE";
    this.iconName = "knifeIcon";

    this.game.add.existing(this);
    this.anchor.set(0.5,0.5);

    if(!isStartingFuture())
    {
      this.pickUp();
    }
  }

  inspect()
  {
    if(isStartingFuture())
    {
      sendData("KNIFE_FOUND");
      return "I must have left this knife here...";
    }
    else {
      return "Huh, never noticed this knife here before";
    }
  }

  canPickUp()
  {
    return true;
  }

  pickUp()
  {
    this.visible = false;
  }

  messageRecieved(data)
  {
    super.messageRecieved(data);
    if(data === "KNIFE_FOUND")
    {
      this.visible = true;
    }
  }


}
