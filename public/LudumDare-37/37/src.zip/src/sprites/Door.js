import Phaser from 'phaser'

let treeStates = {
  UPRIGHT:0,
  FALLEN_OVER:1,
  ON_FIRE:2,
  UPRIGHT_LIGHTS:3,
  UPRIGHT_BAUBLES:4,
  UPRIGHT_LIGHTS_BAUBLES:5,
}

export default class extends Phaser.Sprite {

  constructor (engine) {

    let x = 105;
    let y = 149;
    let asset = 'door';
    let position = new Phaser.Point(366,204);

    super(engine.game, x, y, asset);
    this.characterPosition = position;

    this.clicked = new Phaser.Signal();

    this.engine = engine;

    this.game = engine.game;
    this.game.add.existing(this);

    this.anchor.setTo(0.5,1)
    this.inputEnabled = true;
    this.events.onInputDown.add(this.objectClicked, this);

  }

  objectClicked()
  {
    this.clicked.dispatch(this);
  }

  getSubtitleComplete()
  {
    return "Oh yes! This tree is perfect! What a wonderful Christmas it will be!";
  }

  getSubtitleMoreToDO()
  {
    console.log(this.engine.tree.getState());
    if(isStartingFuture())
    {
      switch(this.engine.tree.getState())
      {
        case treeStates.UPRIGHT:
        return "I couldnt leave without decorating the tree!";
        break;
        case treeStates.FALLEN_OVER:
        return "I can't leave it like this!";
        break;
        case treeStates.ON_FIRE:
        return "Yeah, I should just leave...";
        break;
        case treeStates.UPRIGHT_LIGHTS:
        return "Ah, now its Christmas!";
        break;
        case treeStates.UPRIGHT_BAUBLES:
        break;
        case treeStates.UPRIGHT_LIGHTS_BAUBLES:
        break;
      }
    }
    else {
      switch(this.engine.tree.getState())
      {
        case treeStates.UPRIGHT:
        return "I couldnt leave without decorating the tree!";
        break;
        case treeStates.FALLEN_OVER:
        return "It's a disaster!";
        break;
        case treeStates.ON_FIRE:
        return "Well...";
        break;
        case treeStates.UPRIGHT_LIGHTS:
        return "While the tree does look pretty great,\nI have a feeling something isnt right...";
        break;
        case treeStates.UPRIGHT_BAUBLES:
        break;
        case treeStates.UPRIGHT_LIGHTS_BAUBLES:
        break;
      }
    }
  }

}
