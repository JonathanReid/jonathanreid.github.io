import Phaser from 'phaser';
import InventoryItem from '../sprites/InventoryItem';

export default class extends InventoryItem {

  constructor (game) {

    let x = 70;
    let y = 158;
    let asset = 'rope';
    let position = new Phaser.Point(96,155);

    super(game, x, y, asset,position);
    this.name = "ROPE";
    this.iconName = "ropeIcon";

    this.game.add.existing(this);
    this.anchor.set(0.5,1);

    if(isStartingFuture())
    {
      this.pickUp();
    }

  }

  inspect()
  {
    return "Thats just a pile of rope";
  }

  pickUp()
  {
    this.visible = false;
  }

  messageRecieved(data)
  {
    super.messageRecieved(data);
  }


}
