import Phaser from 'phaser';
import InteractiveObject from '../sprites/InteractiveObject';

let states = {
  UPRIGHT:0,
  FALLEN_OVER:1,
  ON_FIRE:2,
  UPRIGHT_LIGHTS:3,
  UPRIGHT_BAUBLES:4,
  UPRIGHT_LIGHTS_BAUBLES:5,
}

export default class extends InteractiveObject {

  constructor (game) {

    let x = 328;
    let y = 240;
    let asset = 'tree';
    let position = new Phaser.Point(272,194);

    super(game, x, y, asset,position);

    let frames = [0];
    this.animations.add("normal",frames);
    frames = [1];
    this.animations.add("lights",frames);
    frames = [0,0,0,2,3,4,5];
    this.animations.add("fall",frames);
    frames = [6,7,8];
    this.animations.add("onFire",frames);

    this.frame = 0;

    this.currentState = isStartingFuture() ? states.FALLEN_OVER : states.UPRIGHT;
    this.changeState(this.currentState);

    this.game.add.existing(this);
    this.anchor.set(0.5,1);

    this.hitArea = new Phaser.Rectangle(-this.width/2,-this.height,118,190);
  }

  inspect()
  {
    switch(this.currentState)
    {
      case states.UPRIGHT:
      return "Thats a fine looking tree";
      break;
      case states.FALLEN_OVER:
      return "This is a disaster!";
      break;
      case states.ON_FIRE:
      return "I... What... HOW?!";
      break;
      case states.UPRIGHT_LIGHTS:
      return "Such sparkly and wonderous, so pretty and perfect.";
      break;
    }
  }

  useItemOn(item)
  {
    if(item !== undefined)
    {

      if(item.name === "ROPE")
      {
        if(!isStartingFuture())
        {
          sendData("TREE-UPRIGHT");
        }
      }
      if(item.name === "DECORATIONS")
      {
        if(this.currentState == states.UPRIGHT)
        {
          this.changeState(states.UPRIGHT_LIGHTS);
        }
        if(this.currentState == states.UPRIGHT_BAUBLES)
        {
          this.changeState(states.UPRIGHT_LIGHTS_BAUBLES);
        }

        if(!isStartingFuture())
        {
          sendData("TREE-DECORATIONS");
        }
      }
      if(item.name === "BAUBEL")
      {
        if(this.currentState == states.UPRIGHT)
        {
          this.changeState(states.UPRIGHT_BAUBLES);
        }
        if(this.currentState == states.UPRIGHT_LIGHTS)
        {
          this.changeState(states.UPRIGHT_LIGHTS_BAUBLES);
        }
        if(!isStartingFuture())
        {
          sendData("TREE-BAUBEL");
        }
      }
    }
  }

  canUseItem(item)
  {
    if(item !== undefined)
    {
      if(this.currentState === states.UPRIGHT)
      {
        if(item.name === "DECORATIONS" || item.name === "BAUBEL")
        {
          return true;
        }
        else {
          return false;
        }
      }
      else {
        return false;
      }
    }
    else
    {
      return false;
    }
  }

  incorrectItemText(item)
  {
    if(item !== undefined)
    {
      if(item.name === "KEY")
      {
        return "Pretty sure theres no key hole in this tree";
      }
      if(item.name === "OIL")
      {
        return "That wont do it any good";
      }
      if(item.name === "TOWEL")
      {
        return "This tree doesnt really suit a beard.";
      }
      if(item.name == "DECORATIONS")
      {
        return "No.\nThis is no time for decorations and frivolity.\nCHRISTMAS IS RUINED.";
      }
      if(item.name === "OILRAG")
      {
        return "This fine pine doesnt need to be greased up.";
      }
      return "I'm not sure thats right";
    }
  }

  correctItemText(item)
  {
    if(item !== undefined)
    {
      if(item.name === "BAUBEL")
      {
        return "I didnt think it could look any better!";
      }
      if(item.name === "DECORATIONS")
      {
        return "Shine on piney dancer.";
      }
    }
  }

  messageRecieved(data)
  {
    super.messageRecieved(data);
    if(data == "TREE-UPRIGHT")
    {
      this.changeState(states.UPRIGHT);
    }
    if(data == "TREE-DECORATIONS")
    {
      if(this.currentState == states.FALLEN_OVER)
      {
        this.changeState(states.ON_FIRE);
      }
      else if(this.currentState == states.UPRIGHT)
      {
        this.changeState(states.UPRIGHT_LIGHTS);
      }
      else if(this.currentState == states.UPRIGHT_BAUBLES)
      {
        this.changeState(states.UPRIGHT_LIGHTS_BAUBLES);
      }
    }
    if(data == "TREE-BAUBEL")
    {
      if(this.currentState == states.FALLEN_OVER)
      {
        this.changeState(states.ON_FIRE);
      }
      else if(this.currentState == states.UPRIGHT)
      {
        this.changeState(states.UPRIGHT_BAUBLES);
      }
      else if(this.currentState == states.UPRIGHT_LIGHTS)
      {
        this.changeState(states.UPRIGHT_LIGHTS_BAUBLES);
      }
    }
  }

  getState()
  {
    return this.currentState;
  }

  knockOver()
  {
    this.animations.play("fall", 18, false);
    this.currentState = states.FALLEN_OVER;
  }

  setUprightInFuture()
  {
    if(!isStartingFuture())
    {
      sendData("TREE-UPRIGHT");
    }
  }

  changeState(state)
  {
    switch(state)
    {
      case states.UPRIGHT:
      this.frame = 0;
      break;
      case states.FALLEN_OVER:

      this.frame = 5;
      break;
      case states.ON_FIRE:
      this.animations.play("onFire", 12, true);
      break;
      case states.UPRIGHT_LIGHTS:
      this.animations.play("lights", 18, true);
      break;
      case states.UPRIGHT_BAUBLES:
      this.x = 321;
      this.y = 154;
      this.loadTexture('treeBaubles', 0);
      break;
      case states.UPRIGHT_LIGHTS_BAUBLES:
      this.x = 321;
      this.y = 154;
      this.loadTexture('treeLightsBauble', 0);
      break;
    }
    this.currentState = state;
  }

}
