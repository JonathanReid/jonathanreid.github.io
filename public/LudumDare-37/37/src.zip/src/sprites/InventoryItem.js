import Phaser from 'phaser'

export default class extends Phaser.Sprite {

  constructor (game, x, y, asset, position) {

    super(game, x, y, asset)
    this.clicked = new Phaser.Signal();

    this.characterPosition = position;
    this.game = game;
    this.isUsed = false;

    this.inputEnabled = true;
    this.events.onInputDown.add(this.objectClicked, this);

    let context = this;
    this.messageRecievedEvent = function (e) {
      context.messageRecieved(e.detail);
    };
    document.addEventListener('gameMessage', this.messageRecievedEvent );
  }

  objectClicked()
  {
    this.clicked.dispatch(this);
  }

  useItemOn(item)
  {

  }

  showCode()
  {
    return false;
  }

  canUseItem(item)
  {

  }

  canPickUp()
  {
    return true;
  }

  canCombineWith(item)
  {
    return false;
  }

  used()
  {
    this.isUsed = true;
  }

  messageRecieved(data)
  {

  }

  destroy()
  {
    super.destroy();
    document.removeEventListener('gameMessage', this.messageRecievedEvent );
  }

}
