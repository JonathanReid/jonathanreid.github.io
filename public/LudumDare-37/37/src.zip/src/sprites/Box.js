import Phaser from 'phaser';
import InteractiveObject from '../sprites/InteractiveObject';

let boxStates = {
    LOCKED: 0,
    UNLOCKED:1,
    EMPTY:2,
}

export default class extends InteractiveObject {

  constructor (game) {

    let x = 200;
    let y = 127;
    let asset = 'box';
    let position = new Phaser.Point(197,186);

    super(game, x, y, asset,position);

    this.game.add.existing(this);
    this.anchor.set(0.5,0.5);
    this.hasNote = false;
    this.shouldEnterCode = false;

    let min = 1000;
    let max = 9999;
    let num = Math.floor(Math.random() * (max - min + 1)) + min;

    this.currentState = boxStates.LOCKED;

    if(isStartingFuture())
    {
      this.currentState = boxStates.EMPTY;
      this.hasNote = true;
      this.combination = num.toString();
      this.loadTexture("boxUnlocked");

      setSharedData(this.combination);
    }
    else {
      this.combination = getSharedData();
    }
  }

  showCode()
  {
    return this.shouldEnterCode;
  }

  inspect()
  {
    if(this.currentState == boxStates.LOCKED)
    {
      this.shouldEnterCode = true;
      return "It's locked, and I've forgotten the combination!";
    }
    else if(this.currentState == boxStates.UNLOCKED)
    {
      return "Theres just a can of oil in here.\nNot sure why I locked it...";
    }
    else if(isStartingFuture() && this.currentState == boxStates.EMPTY)
    {
      this.setOpened();
      return "Theres some writing on the lid.\nIt says: " + this.combination+"\nHuh.";
    }
    else if(this.currentState == boxStates.EMPTY)
    {
      return "Just an oily storage box. Not much to see here.";
    }
  }

  itemsRetrievedOnInspect()
  {
    if(this.currentState == boxStates.UNLOCKED)
    {
      let items = [];
      items.push("OIL");
      this.currentState = boxStates.EMPTY;
      return items;
    }
    else if(isStartingFuture() && this.currentState == boxStates.EMPTY && this.hasNote)
    {
      this.hasNote = false;
      let items = [];
      items.push("NOTE");
      this.currentState = boxStates.EMPTY;
      return items;
    }
    else {
      return [];
    }
  }

  canUseItem(item)
  {
    if(item !== undefined)
    {
      if(item.name === "KEY")
      {
        return true;
      }
      else {
        return false;
      }
    }
    else
    {
      return false;
    }
  }

  incorrectItemText(item)
  {
    if(item !== undefined)
    {
      if(item.name === "OIL")
      {
        return "I just took that from here...";
      }
      if(item.name === "TOWEL")
      {
        return "This beard is too good for that box";
      }
      if(item.name === "DECORATIONS")
      {
        return "Thats too pretty to go in there";
      }

      return "I'm not sure thats right";
    }
  }

  correctItemText(item)
  {
    console.log(item.name);
    if(item !== undefined)
    {

      if(item.name === "KEY")
      {
        return "And with a creaky turn of the lock,\nthe old box opens up to reveal\nthe treasures of some junky tools.";
      }
    }
  }

  useItemOn(item)
  {
    if(item !== undefined)
    {
      console.log("using " + item.name + " on box" );
      if(item.name === "KEY")
      {
        this.unlocked();
        item.used();
      }
    }
  }

  unlocked()
  {
    this.currentState = boxStates.UNLOCKED;
    this.shouldEnterCode = false;
    this.setOpened();
    if(!isStartingFuture())
    {
      sendData("BOX_UNLOCKED");
    }
  }

  setOpened()
  {
    this.loadTexture("boxOpen");
  }

  messageRecieved(data)
  {
    super.messageRecieved(data);
    if(isStartingFuture())
    {
      if(data == "BOX_UNLOCKED")
      {
        // this.currentState = boxStates.UNLOCKED;
      }
    }
  }

}
