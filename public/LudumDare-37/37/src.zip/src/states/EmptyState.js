/* globals __DEV__ */
import Phaser from 'phaser'
import {setResponsiveWidth} from '../libs/utils'
import BaseState from '../libs/states/BaseState'
import GameServices from '../boot/GameServices';
import TimeOverlay from '../sprites/TimeOverlay';

export default class extends BaseState {
  init () {}
  preload () {}

  create () {
    if(!isStartingFuture())
    {
      this.state.start('PastGame');
    }
    else {
      this.state.start('FutureGame');
    }
  }

  render () {

  }
}
