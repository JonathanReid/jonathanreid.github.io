/* globals __DEV__ */
import Phaser from 'phaser'
import {setResponsiveWidth} from '../libs/utils'
import BaseState from '../libs/states/BaseState'
import GameServices from '../boot/GameServices';
import TimeOverlay from '../sprites/TimeOverlay';

export default class extends BaseState {
  init () {}
  preload () {}

  create () {

    this.createTitle();
    this.createPlayButton();
    this.createLink();
    this.inThePast = true;

    let context = this;

    if(isReadyToStart())
    {
      this.gameReady();
      this.inThePast = false;
    }
    else {
      this.createDesc();
      this.gameReady = function (e) {
        context.pastGameReady();
      };
      document.addEventListener('gameReadyEvent', this.gameReady);
    }

    this.gameMessageEvent = function (e) {
      context.gameMessage(e.detail);
    };
    document.addEventListener('gameMessage', this.gameMessageEvent);

    this.overlay = new TimeOverlay(this);
  }

  createTitle()
  {
    // this.text = game.add.bitmapText(this.game.world.centerX, 30, 'pixelFont','A tim',32);
    // this.text.anchor.set(0.5);
    // this.text.tint = "0x000000";

    this.bg = this.game.add.sprite(0,0,"menuBG");
    this.bg.anchor.set(0,0);

    this.title = this.game.add.sprite(0,-100,"title");
    this.title.anchor.set(0,0);

    this.game.add.tween(this.title).to( {y:0,}, 1000, Phaser.Easing.Quadratic.Out, true);
    GameServices.Sound.playSound("titleInSFX");
  }

  createDesc()
  {
    this.desc = game.add.bitmapText(this.game.world.centerX, this.game.world.height-40, 'pixelFont','This game needs to be running in two tabs at once.\nOpen it in another tab to start',16);
    this.desc.anchor.set(0.5);
    this.desc.tint = "0x000000";
    this.desc.align = "center";
  }

  createLink()
  {
    this.link = game.add.bitmapText(this.game.world.centerX, this.game.world.height-10, 'pixelFont','jonsgames.com',16);
    this.link.anchor.set(0.5);
    this.link.tint = "0x000000";
    this.link.align = "center";
    this.link.inputEnabled = true;
    this.link.events.onInputDown.add(this.goToLink, this);
  }

  goToLink()
  {
    document.location.href = "http://jonsgames.com";
  }

  createPlayButton()
  {
    this.button = this.game.add.button(this.game.world.centerX, this.game.world.centerY+50, 'ui', this.handleButtonClicked, this, 'playbutton1.png', 'playbutton1.png', 'playbutton2.png');
    this.button.anchor.set(0.5);
    this.button.visible = false;
  }

  pastGameReady()
  {
    this.desc.text = "Start the game from the other tab!";
  }

  gameReady()
  {
    this.button.visible = true;
    if(this.desc !== undefined)
    {
      this.desc.visible = false;
    }
  }

  gameMessage(msg)
  {
    if(msg === MESSAGE_START)
    {
      this.overlay.forceShow();
      this.startGame();
    }
  }

  updateLoop()
  {

  }

  handleButtonClicked()
  {
    // this.state.start('Game');
    // this.openServer();
    sendData(MESSAGE_START);
    this.overlay.hide(this.startGame,this);
    GameServices.Sound.playSound("btnPressSFX");
    // this.startGame();
  }

  startGame()
  {
    document.removeEventListener('gameReadyEvent', this.gameReady);
    document.removeEventListener('gameMessage', this.gameMessageEvent);
    if(this.inThePast)
    {
      this.state.start('PastGame');
    }
    else {
      this.state.start('FutureGame');
    }

  }

  render () {
    if (__DEV__) {
      // this.game.debug.spriteInfo(this.mushroom, 32, 32)
    }
  }
}
