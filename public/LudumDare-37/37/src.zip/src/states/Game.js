/* globals __DEV__ */
import Phaser from 'phaser'
import Player from '../sprites/Player'
import Tree from '../sprites/Tree'
import Window from '../sprites/Window'
import Box from '../sprites/Box'
import Rope from '../sprites/Rope'
import Key from '../sprites/Key'
import Knife from '../sprites/Knife'
import Oil from '../sprites/Oil'
import Towel from '../sprites/Towel'
import Baubel from '../sprites/Bauble'
import Decorations from '../sprites/Decorations'
import DecorationBox from '../sprites/DecorationBox'

import Door from '../sprites/Door'
import InventoryItem from '../sprites/InventoryItem'
import InventoryIcon from '../sprites/InventoryIcon'
import TimeOverlay from '../sprites/TimeOverlay'
import {setResponsiveWidth} from '../libs/utils'
import BaseState from '../libs/states/BaseState'
import GameServices from '../boot/GameServices';

export default class extends BaseState {
  preload () {}

  create () {
    this.currentItems = [];
    this.selectedItem = undefined;
    this.allItems = [];
    this.textQueue = [];
    this.inventorySlots = [];
    this.gameTime = 15;
    this.birdHitWindow = false;
    this.complete = false;
    this.seenTreeOnFire = false;
    this.seenTreeComplete = false;
    this.code = "";
    this.runningQueue = false;
    this.enabledInput = false;
    this.isGameOver = false;
    this.gameOverText = false;
    this.gameStarted = false;

    if(!isStartingFuture())
    {
      this.enabledInput = true;
      this.gameStarted  = true;

      sendData("PAST_GAME_STARTED");
    }

    this.keycodes = [Phaser.Keyboard.ZERO,Phaser.Keyboard.ONE,Phaser.Keyboard.TWO,Phaser.Keyboard.THREE,Phaser.Keyboard.FOUR,Phaser.Keyboard.FIVE,Phaser.Keyboard.SIX,Phaser.Keyboard.SEVEN,Phaser.Keyboard.EIGHT,Phaser.Keyboard.NINE];
    this.keys = [];
    this.keyDown = [];
    for(let i = 0; i < this.keycodes.length; ++i)
    {
      this.keys.push(this.game.input.keyboard.addKey(this.keycodes[i]));
      this.keyDown.push(false);
    }

    let context = this;
    this.messageRecievedEvent = function (e) {
      context.messageRecieved(e.detail);
    };
    document.addEventListener('gameMessage', this.messageRecievedEvent);
  }

  createSubtitles()
  {
    let posy = this.game.world.height-50;
    if(isStartingFuture())
    {
      posy = this.game.world.height-25
    }
    this.text = this.game.add.bitmapText(this.game.world.centerX, posy, 'pixelFont',"",16);
    this.text.tint = "0x000000";
    this.text.anchor.set(0.5);

    if(isStartingFuture())
    {
      this.setSubtitle("My tree!");
      this.setSubtitle("If only I could go back 15 minutes");
      this.setSubtitle("and stop this from happening!");
      this.setSubtitle("(switch tabs to alter Christmas Past)");
    }

  }

  tabInForeground()
  {
    super.tabInForeground();

  }

  createOverlay()
  {
    this.overlay = new TimeOverlay(this);
    if(!isStartingFuture()) {
      this.overlay.show(true,this.showOverlayComplete,this);
    }
  }

  showOverlayComplete()
  {
    this.setSubtitle("Time to decorate this tree!");
  }

  gameOver()
  {
    this.isGameOver = true;
    let context = this;
    this.gameResetEvent = function (e) {
      context.gameReset();
    };
    document.addEventListener('gameResetEvent', this.gameResetEvent);
  }

  gameReset()
  {
    document.removeEventListener('gameResetEvent', this.gameResetEvent);
    this.state.start('EmptyState');
  }

  gameWon()
  {

  }

  createInitialInventorySlots()
  {


    if(!isStartingFuture())
    {
      this.itemsTitle = this.game.add.sprite(10,240,"itemsTitle");
      this.itemsTitle.anchor.set(0,0);
      for(let i = 0; i < 5; ++i)
      {
        let slot = new InventoryIcon(this.game, i,240,"emptyIconSlot");
        this.inventorySlots.push(slot);
        slot.clicked.add(this.handleInventoryItemSelected,this);
      }
    }
  }

  createCharacter()
  {
    this.definedPolygonWalkArea();
    this.game.physics.startSystem(Phaser.Physics.ARCADE);

    this.game.time.desiredFps = 60;
    this.game.physics.arcade.gravity.y = 0;

    this.player = new Player({
      game: this.game,
      x: this.game.world.centerX,
      y: 180,
      asset: 'char'
    })
    this.player.anchor.set(0.5,1);

    // this.game.physics.enable(this.player, Phaser.Physics.ARCADE);
    // this.game.physics.arcade.bounds = new Phaser.Rectangle(this.room.x,this.room.y,this.room.width,this.room.height-15);
    // this.player.body.collideWorldBounds = true;

    // set the sprite width to 30% of the game width
    // setResponsiveWidth(this.player, 30, this.game.world)
    this.game.add.existing(this.player);

    this.game.input.onTap.add(this.handleTap, this);
  }

  createItems()
  {
    this.door = new Door(this);
    this.door.clicked.add(this.handleDoorClicked,this);

    this.window = new Window(this.game);
    this.window.clicked.add(this.handleObjectClicked,this);

    this.box = new Box(this.game);
    this.box.clicked.add(this.handleObjectClicked,this);

    this.decs = this.game.make.sprite(0,0,"hangingDecorations");
    this.decs.anchor.set(0);
    this.game.add.existing(this.decs);

    this.towel = new Towel(this.game);
    this.towel.clicked.add(this.handleInventoryItemClicked, this);
    this.allItems.push(this.towel);

    this.tree = new Tree(this.game);
    this.tree.clicked.add(this.handleObjectClicked,this);

    // this.rope = new Rope(this.game);
    // this.rope.clicked.add(this.handleInventoryItemClicked, this);
    // this.allItems.push(this.rope);
    //
    this.knife = new Knife(this.game);
    this.knife.clicked.add(this.handleInventoryItemClicked, this);
    this.allItems.push(this.knife);

    this.oil = new Oil(this.game);
    this.oil.clicked.add(this.handleInventoryItemClicked, this);
    this.allItems.push(this.oil);

    this.decorations = new Decorations(this.game);
    this.decorations.clicked.add(this.handleInventoryItemClicked, this);
    this.allItems.push(this.decorations);

    this.decorationBox = new DecorationBox(this.game);
    this.decorationBox.clicked.add(this.handleObjectClicked, this);


    // this.allItems.push(this.decorations);

    this.bird = this.game.make.sprite(0,0,"bird");
    this.bird.anchor.set(0.5,0.5);
    this.bird.visible = false;
    // this.bird.frame = 15;
    this.bird.position.set(this.window.position.x+19,this.window.position.y-7);
    let frames = [0,1,2,3,4,5,6,7,8];
    this.bird.animations.add("hitTree",frames);
    frames = [8,8,8,8,8,8,8,8,8,8,9,10,11,11,11,11,11,12,13,14,15,16,17,8];
    this.bird.animations.add("hitWindow",frames);
    this.game.add.existing(this.bird);

    this.birdWindowOverlay = this.game.make.sprite(0,0,"bird");
    this.birdWindowOverlay.anchor.set(0.5,0.5);
    this.birdWindowOverlay.visible = false;
    // this.birdWindowOverlay.frame = 24;
    this.birdWindowOverlay.position.set(this.window.position.x+19,this.window.position.y-7);
    frames = [8,8,8,8,8,8,8,8,8,8,18,19,20,20,20,20,20,21,22,23,24,25,26,8];
    this.birdWindowOverlay.animations.add("hitWindow",frames);
    this.birdWindowOverlay.alpha = 0.5;
    this.game.add.existing(this.birdWindowOverlay);

  }

  definedPolygonWalkArea()
  {
    this.poly = new Phaser.Polygon();

    //  And then populate it via setTo, using any combination of values as above
    this.poly.setTo([ new Phaser.Point(90, 205), new Phaser.Point(109, 165), new Phaser.Point(278, 165), new Phaser.Point(300, 205), new Phaser.Point(300, 240), new Phaser.Point(80, 240) ]);

    // let graphics = this.game.add.graphics(0, 0);
    //
    // graphics.beginFill(0xFF33ff);
    // graphics.drawPolygon(this.poly.points);
    // graphics.endFill();
  }

  getPointInPolygon(p)
  {
    if(this.poly.contains(p.x,p.y))
    {
      return true;
    }
    return false;
  }

  createRoom()
  {
    this.room = this.game.make.sprite(0,0,"room");
    this.game.add.existing(this.room);
    this.room.anchor.set(0);
    this.createItems();
  }

  updateLoop()
  {
    if(isStartingFuture())
    {
      if(!this.seenTreeOnFire && this.tree.currentState == 2)
      {
        this.seenTreeOnFire = true;
        sendData("FUTURE_GAMEOVER");
        this.clearQueue();
        this.gameOverText = true;
        this.setSubtitle("How did that happen!");
        this.gameOver();
      }
      if(!this.seenTreeComplete && this.tree.currentState == 3)
      {
        this.seenTreeComplete = true;
        sendData("FUTURE_GAMEWON");
        this.setSubtitle("SO PRETTY!");
        this.gameOver();
      }
    }

    if(this.canEnterCode)
    {
      for(let i = 0; i < this.keys.length; ++i)
      {
          if(this.keys[i].isDown && !this.keyDown[i])
          {
            this.code += i.toString();
          }

          this.keyDown[i] = this.keys[i].isDown;
      }

      this.text.text = "ENTER CODE: "+this.code;

      if(this.code.length == 4)
      {
        if(this.code === this.box.combination)
        {
          this.box.unlocked();
          this.clearCode();
          let t = this.inspectObjectOnFinish.inspect();

          let items = this.inspectObjectOnFinish.itemsRetrievedOnInspect();
          this.pickUpItemsAfterInspection(items);
          this.clearQueue();
          this.setSubtitle(t);
        }
        else {
            this.code = "";
            this.clearQueue();
            this.setSubtitle("Nope, that didnt do it.");
        }
        this.canEnterCode = false;
        this.inspectObjectOnFinish = undefined;
      }
    }
  }

  timesUp()
  {
    if(this.window.isOpen())
    {
      this.bird.visible = true;
      // this.bird.scale.set(0,0);
      this.bird.position.set(this.window.position.x+40,this.window.position.y);

      this.bird.animations.play("hitTree", 18, false);
      this.birdHitTree();

      // this.game.add.tween(this.bird).to( {x:this.tree.x,}, 500, Phaser.Easing.Quadratic.In, true).onComplete.add(this.birdHitTree,this);
      // this.game.add.tween(this.bird.scale).to( {x:1,y:1}, 500, Phaser.Easing.Quadratic.In, true);
    }
  }

  birdHitTree()
  {
    this.enabledInput = false;
    // this.bird.visible = false;
    this.clearQueue();
    this.tree.knockOver();

    GameServices.Sound.playSound("sndBirdHitWindow");

    this.setSubtitle("My tree!");
    this.setSubtitle("If only I could go back 15 minutes");
    this.setSubtitle("and stop this from happening!");

    sendData("FORCE_PAST_GAMEOVER");

    setHowGameCompleted("Bird");

    this.gameOver();
  }

  birdHitsWindow()
  {
    if(!this.birdHitWindow)
    {
      this.bird.position.set(this.window.position.x+19,this.window.position.y-7);
      this.birdWindowOverlay.position.set(this.window.position.x+19,this.window.position.y-7);

      this.bird.animations.play("hitWindow", 18, false);
      this.birdWindowOverlay.animations.play("hitWindow", 18, false);
      this.bird.visible = true;
      this.birdWindowOverlay.visible = true;



      this.birdHitWindow = true;
      this.tree.setUprightInFuture();
      // this.setSubtitle("*BIRD HITS WINDOW*");

      let context = this;
      this.interval = window.setInterval(this.delayedSubtitlesAfterBirdHitsWindow,1000,context);
      this.interval2 = window.setInterval(this.delayedBirdHitsWindowSound,800,context);
    }
  }

  delayedBirdHitsWindowSound(context)
  {
    GameServices.Sound.playSound("sndBirdHitWindow");
    window.clearInterval(context.interval2);
  }

  delayedSubtitlesAfterBirdHitsWindow(context)
  {

    window.clearInterval(context.interval);
    this.clearQueue();
    context.setSubtitle("Oh just in time,\nthat bird could have knocked over my tree!");
    context.setSubtitle("the problems that would cause!");
  }

  handleTap()
  {
    if(this.enabledInput)
    {
      let p = this.game.input.activePointer.position;
      if(this.getPointInPolygon(p) && this.inspectObjectOnFinish === undefined && this.pickupObjectOnFinish === undefined)
      {
        p.y += 10;
        this.inspectObjectOnFinish = undefined;
        this.moveCharacter(p);
        this.clearCode();
      }
    }
  }

  moveCharacter(p)
  {
    this.clearQueue();
    let t = (this.player.position.distance(p,true))/100;
    if(this.moveTween !== undefined)
    {
      this.moveTween.stop();
      this.player.stop();
    }
    if(this.player.position.distance(p,true) < 5)
    {
      this.characterArrivedAtPoint();
    }
    else{
      this.moveTween = this.game.add.tween(this.player);
      if(p.x < this.player.position.x)
      {
        this.player.scale.set(-1,1);
      }
      else {
        this.player.scale.set(1,1);
      }
      this.player.move();
      this.moveTween.to( {x:p.x, y: p.y }, t*1000, Phaser.Easing.Linear.none, true).onComplete.add(this.characterArrivedAtPoint,this);
    }
  }

  handleDoorClicked(item)
  {
    if(this.enabledInput)
    {
      if(this.complete)
      {
        this.clearQueue();
          this.setSubtitle(item.getSubtitleComplete());
      }
      else {
        this.clearQueue();
        this.setSubtitle(item.getSubtitleMoreToDO());
      }
    }
  }

  handleObjectClicked(item)
  {
    if(this.enabledInput)
    {
      this.inspectObjectOnFinish = item;
      this.moveCharacter(item.characterPosition);
    }
  }

  handleInventoryItemClicked(item)
  {
    if(this.enabledInput)
    {
      if(item.canPickUp())
      {
        this.pickupObjectOnFinish = item;
      }
      this.moveCharacter(item.characterPosition);
    }
  }

  characterArrivedAtPoint()
  {
    this.player.stop();
    if(this.inspectObjectOnFinish !== undefined)
    {
      let showInspectionText = true;
      if(this.selectedItem !== undefined)
      {
        if(this.inspectObjectOnFinish.canUseItem(this.selectedItem.getItem()))
        {
          showInspectionText = false;
          this.inspectObjectOnFinish.useItemOn(this.selectedItem.getItem());

          let t = this.inspectObjectOnFinish.correctItemText(this.selectedItem.getItem());
          this.clearQueue();
          this.setSubtitle(t);
          this.usedInventoryItem(this.selectedItem);

          if(!this.window.isOpen())
          {
            this.birdHitsWindow();
          }
        }
        else {
          this.clearQueue();
          this.setSubtitle(this.inspectObjectOnFinish.incorrectItemText(this.selectedItem.getItem()));
          showInspectionText = false;
        }
      }
      if(showInspectionText)
      {
        if(this.inspectObjectOnFinish.showCode())
        {
          this.enterCode();
        }
        else{
          let t = this.inspectObjectOnFinish.inspect();
          let items = this.inspectObjectOnFinish.itemsRetrievedOnInspect();
          this.pickUpItemsAfterInspection(items);
          this.clearQueue();
          this.setSubtitle(t);
          this.inspectObjectOnFinish = undefined;
        }
      }
      else {
          this.inspectObjectOnFinish = undefined;
      }
    }
    if(this.pickupObjectOnFinish !== undefined)
    {
      this.clearQueue();
      this.setSubtitle(this.pickupObjectOnFinish.inspect());
      this.pickUpItem(this.pickupObjectOnFinish,false);
      this.pickupObjectOnFinish = undefined;
    }

    if(this.selectedItem !== undefined)
    {
      this.selectedItem.deselectItem();
      this.selectedItem = undefined;
    }
  }

  pickUpItemsAfterInspection(items)
  {
    for(let i = 0; i < items.length; i++)
    {

      for(let j = 0; j < this.allItems.length; j++)
      {
        // console.log(items[i] + " " + this.allItems[j].name);
        if(items[i] === this.allItems[j].name)
        {
          this.pickUpItem(this.allItems[j]);
        }
      }
    }
  }

  setSubtitle(text)
  {
    if(!this.isGameOver)
    {
      let t = text.split('\n');
      for(let i = 0; i < t.length; i++)
      {
        this.textQueue.push(t[i]);
      }
      if(this.textQueue.length >= 1 && this.runningQueue == false)
      {
        this.resolveTextQueue();
      }
    }
  }

  enterCode()
  {
    this.canEnterCode = true;
    this.text.text = "ENTER CODE: ";
  }

  clearCode()
  {
    this.canEnterCode = false;
    this.text.text = "";
  }

  clearQueue()
  {
    this.textQueue = [];
    this.runningQueue = false;
    this.text.text = "";
    if(this.textTimer !== undefined)
    {
      this.game.time.events.remove(this.textTimer);
    }
  }

  resolveTextQueue()
  {
    if(this.textQueue.length > 0)
    {
      this.runningQueue = true;
      this.text.text = this.textQueue[0];
      let t = this.text.text.length*100;
      if(!this.gameOverText)
      {
        t = Math.max(t,2000);
      }
      else {
        t = 4000;
      }
      if(this.textTimer !== undefined)
      {
        this.game.time.events.remove(this.textTimer);
      }
      this.textTimer = this.game.time.events.add(t, this.restartTextQueue, this);
    }
    else {

      this.text.text = "";
      this.runningQueue = false;
      if(!this.isGameOver)
      {
        if(this.gameStarted)
        {
          this.enabledInput = true;
        }
      }
      else {
        // console.log("SHOULD NOW GO TO BLACK AND THEN GAME OVER");
        this.goToGameOver();
        sendData("FUTURE_FORCE_GAMEOVER");
      }
    }
  }

  restartTextQueue()
  {
    this.textQueue.splice(0,1);
    this.resolveTextQueue();
  }

  usedInventoryItem(item)
  {
    // if(item.activeItem.name == "TOWEL")
    // {
    //   this.player.takeOffBeard();
    // }
    // console.log("usedInventoryItem ---  " + item.activeItem.name);
    item.useItem();
    let index = this.currentItems.indexOf(item);
    this.currentItems.splice(index,1);
  }

  pickUpItem(item, receivedAsMessage)
  {
    if(this.currentItems.indexOf(item) == -1)
    {
      item.pickUp();
      this.currentItems.push(item);
    }
    if(!receivedAsMessage)
    {
      if(!isStartingFuture())
      {
        sendData("PAST_INVENTORY_"+item.name);
      }
      else {
        sendData("FUTURE_INVENTORY_"+item.name);
      }

      GameServices.Sound.playSound("sndPickup");
    }
    this.updateInventoryDisplay();
  }

  updateInventoryDisplay()
  {
    for(let i = 0; i < this.inventorySlots.length; i++)
    {
      if(i <= this.currentItems.length-1)
      {
        this.inventorySlots[i].setItem(this.currentItems[i]);
      }
    }
  }

  handleInventoryItemSelected(item)
  {
    if(this.enabledInput)
    {
      if(this.selectedItem === undefined)
      {
        this.selectedItem = item;
        item.selectItem();
      }
      else if(this.selectedItem == item)
      {
        item.deselectItem();
        this.selectedItem = undefined;
      }
      else {
        if(item.combine(this.selectedItem))
        {
          this.selectedItem.deselectItem();
          this.usedInventoryItem(this.selectedItem);
          this.selectedItem = item;
          item.selectItem();
        }else {
          this.selectedItem.deselectItem();
          this.selectedItem = item;
          item.selectItem();
        }
      }

      if(this.selectedItem !== undefined && this.selectedItem.activeItem !== undefined)
      {
        this.clearQueue();
        this.setSubtitle(this.selectedItem.activeItem.inspect());
      }
    }
  }

  messageRecieved(data)
  {
    if(isStartingFuture())
    {
      if(data.includes("PAST_INVENTORY"))
      {
        let name = data.replace("PAST_INVENTORY_","");

        for(let i = 0; i < this.allItems.length; ++i)
        {
          if(this.allItems[i].name === name)
          {
            this.pickUpItem(this.allItems[i],true);
            if(name == "TOWEL")
            {
              this.player.wearBeard();
            }
          }
        }
      }
      else if(data.includes("FUTURE_INVENTORY"))
      {
        let name = data.replace("FUTURE_INVENTORY_","");

        for(let i = 0; i < this.allItems.length; ++i)
        {
          if(this.allItems[i].name === name)
          {
            this.pickUpItem(this.allItems[i],true);
          }
        }
      }

      if(data.includes("USED_ITEM_"))
      {
        let name = data.replace("USED_ITEM_","");
        for(let i = 0; i < this.inventorySlots.length; ++i)
        {
          if(this.inventorySlots[i].getItem() !== undefined)
          {
            // console.log(name);
            if((name == "TOWEL" && this.inventorySlots[i].getItem().name == "OIL") || name == "OIL" && this.inventorySlots[i].getItem().name == "TOWEL")
            {
              this.usedInventoryItem(this.inventorySlots[i]);
              this.updateInventoryDisplay();
            }
            if(this.inventorySlots[i].getItem().name === name)
            {
              // this.inventorySlots[i].useItem();
              this.usedInventoryItem(this.inventorySlots[i]);
              this.updateInventoryDisplay();
            }
          }
        }
        this.updateInventoryDisplay();

        if(name == "OIL" || name == "TOWEL")
        {
          this.player.wearOilyBeard();
        }
      }

      if(data == "PAST_GAMEOVER")
      {
        this.clearQueue();
        this.gameOver();
        this.goToGameOver();
      }

      // console.log(data);
      if(data == "FORCE_PAST_GAMEOVER")
      {
        this.clearQueue();
        this.gameOver();
          this.moveToGameOverState();
      }

      if(data == "PAST_GAME_STARTED")
      {
        this.clearQueue();
        this.gameStarted = true;
        this.enabledInput = true;
      }
    }
    else {
      if(data == "FUTURE_GAMEOVER")
      {
        this.setSubtitle("Oooh, I dont think this will end well.");
        this.setSubtitle("(Switch to Christmas Present to see outcome)");
        this.enabledInput = false;
        setHowGameCompleted("Fire");
        this.gameOver();
      }

      if(data == "FUTURE_GAMEWON")
      {
        this.setSubtitle("I have a good feeling about this.");
        this.enabledInput = false;
        setHowGameCompleted("Won");
        this.gameOver();
      }

      if(data == "FUTURE_FORCE_GAMEOVER")
      {
          this.moveToGameOverState();
      }
    }
  }

  goToGameOver()
  {
    this.overlay.hide(this.moveToGameOverState,this);
    // this.state.start('GameOver');
  }

  moveToGameOverState()
  {
      this.state.start('GameOver');
  }

  render () {
    if (__DEV__) {
      let p = this.game.input.activePointer.position;
      // this.game.debug.text( "x: " + Math.ceil(p.x) + " y: " + Math.ceil(p.y), 40, 40 );
      // this.game.debug.spriteI nfo(this.player, 32, 32)
      // this.game.debug.body(this.roomFront);
      // this.game.debug.body(this.player);
    }
  }

  destroy()
  {
    super.destroy();
    document.removeEventListener('gameMessage', this.messageRecievedEvent);
  }
}
