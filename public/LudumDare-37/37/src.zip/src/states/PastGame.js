/* globals __DEV__ */
import Phaser from 'phaser'
import {setResponsiveWidth} from '../libs/utils'
import BaseGame from '../states/Game'

export default class extends BaseGame {
  preload () {}

  create () {
    super.create();

    document.title = "Christmas Past";
    this.createRoom();
    this.createCharacter();

    this.createSubtitles();
    this.createInitialInventorySlots();

    this.createOverlay();

    let context = this;
    this.interval = window.setInterval(this.timer,1000,context);
  }

  updateLoop()
  {
    super.updateLoop();

  }

  tabInBackground()
  {
    let context = this;
    window.clearInterval(context.interval);
  }

  tabInForeground()
  {
    let context = this;
    this.interval = window.setInterval(this.timer,1000,context);
  }

  timer(context) {
    // console.log(context.isGameOver + " " + context.enabledInput);
    if(!context.isGameOver && context.enabledInput)
    {
      context.gameTime -= 1/30;
      // window.document.title = Math.ceil(context.gameTime) + "minutes earlier";

      if(context.gameTime <= 0)
      {
        context.timesUp();
        window.clearInterval(context.interval);
      }
    }
  }


  render () {
    super.render();
    if (__DEV__) {
      // this.game.debug.spriteInfo(this.mushroom, 32, 32)
    }
  }
}
