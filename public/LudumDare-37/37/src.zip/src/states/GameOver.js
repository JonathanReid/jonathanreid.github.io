/* globals __DEV__ */
import Phaser from 'phaser'
import {setResponsiveWidth} from '../libs/utils'
import BaseState from '../libs/states/BaseState'
import GameServices from '../boot/GameServices';

export default class extends BaseState {
  init () {}
  preload () {}

  create () {

    this.createTitle();
    this.createPlayButton();

    let context = this;
    document.addEventListener('gameResetEvent', function (e) {
      context.gameReset();
    });
  }

  createTitle()
  {

    this.bg = this.game.add.sprite(0,0,"menuBG");
    this.bg.anchor.set(0,0);

    this.pixel = this.game.add.sprite(this.game.world.centerX,this.game.world.centerY,"whitePixel");
    this.pixel.anchor.set(0.5,0.5);

    this.pixel.scale.set(350,220);
    this.pixel.alpha = 0.6;

    let completed = getHowGameCompleted();
    let string = "";
    console.log(completed);
    if(completed == "Fire")
    {
      string = "You ruined christmas!";
    }
    if(completed == "Bird")
    {
      string = "Time is a circle";
    }
    if(completed == "Won")
    {
      string = "Well done!";
    }

    this.text = game.add.bitmapText(this.game.world.centerX, 60, 'pixelFont',string,32);
    this.text.anchor.set(0.5);
    this.text.tint = "0x000000";

    let body = "Thanks for playing!\n\nTheres a few different ways to mess with time in this game, make sure to check the present time to see what effect you are having from the past!";
    this.body = game.add.bitmapText(this.game.world.centerX, this.game.world.centerY, 'pixelFont',body,16);
    this.body.anchor.set(0.5);
    this.body.tint = "0x000000";
    this.body.maxWidth = 300;
    this.body.align = "center";
  }

  createPlayButton()
  {
    this.button = this.game.add.button(this.game.world.centerX, this.game.world.centerY+80, 'ui', this.handleButtonClicked, this, 'replaybutton1.png', 'replaybutton1.png', 'replaybutton2.png');
    this.button.anchor.set(0.5);
  }

  handleButtonClicked()
  {
    // this.state.start('Game');
    // this.openServer();
    // sendData(MESSAGE_START);
    // this.overlay.hide(this.startGame,this);
    reset();
    resetOtherInstance();
    GameServices.Sound.playSound("btnPressSFX");
    this.startGame();
    // this.startGame();
  }

  gameReset()
  {
    console.log("RESET GAME NOW!!!");
    reset();
    this.startGame();
  }

  startGame()
  {
    if(!isStartingFuture())
    {
      this.state.start('PastGame');
    }
    else {
      this.state.start('FutureGame');
    }
  }

  updateLoop()
  {

  }

  render () {
    if (__DEV__) {
      // this.game.debug.spriteInfo(this.mushroom, 32, 32)
    }
  }
}
