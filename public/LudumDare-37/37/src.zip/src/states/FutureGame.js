/* globals __DEV__ */
import Phaser from 'phaser'
import {setResponsiveWidth} from '../libs/utils'
import BaseGame from '../states/Game'

export default class extends BaseGame {

  preload () {}

  create () {
    super.create();

    document.title = "Christmas Present";
    this.createRoom();
    this.createCharacter();

    this.createSubtitles();
    this.createInitialInventorySlots();

    this.createOverlay();
  }

  updateLoop()
  {
    super.updateLoop();
  }

  render () {
    super.render();
    if (__DEV__) {
      // this.game.debug.spriteInfo(this.mushroom, 32, 32)
    }
  }
}
