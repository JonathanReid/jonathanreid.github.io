import 'pixi'
import 'p2'
import Phaser from 'phaser'

import BootState from './boot/Boot'
import PreloaderState from './boot/Preloader'
import FutureGame from './states/FutureGame'
import PastGame from './states/PastGame'
import MainMenu from './states/MainMenu'
import GameOver from './states/GameOver'
import EmptyState from './states/EmptyState'


class Game extends Phaser.Game {

  constructor () {
    let width = 400;
    let height = 280;

    let config = {renderer: Phaser.AUTO,  width: width,  height: height, parent: 'content'}

    super(config)

    this.state.add('Boot', BootState, false);
    this.state.add('Preloader', PreloaderState, false);
    this.state.add('MainMenu', MainMenu, false);
    this.state.add('PastGame', PastGame, false);
    this.state.add('FutureGame', FutureGame, false);
    this.state.add('GameOver', GameOver, false);
    this.state.add('EmptyState', EmptyState, false);


    this.state.start('Boot')

  }

}

window.game = new Game()
