import Phaser from 'phaser'
import { centerGameObjects } from '../libs/utils';
import AssetPack from '../libs/assets/assetPack';

export default class extends Phaser.State {
  init () {}

  preload () {
    this.createPreloader();
    this.loadAssets();
  }

  createPreloader()
  {
    this.loaderBg = this.add.sprite(this.game.world.centerX, this.game.world.centerY, 'loaderBg')

    this.loaderBar = this.add.sprite(this.game.world.centerX, this.game.world.centerY, 'loaderBar')
    this.loaderBg.anchor.set(0.5,0.5);
    this.loaderBar.anchor.set(0,0.5);
    this.loaderBar.x-=this.loaderBar.width/2;

    // centerGameObjects([this.loaderBg, this.loaderBar])

    this.load.setPreloadSprite(this.loaderBar)
  }

  loadAssets()
  {
    let gameContent = this.game.cache.getXML('fileList');

    let item = gameContent.getElementsByTagName("file");
    for (let j = 0; j < item.length; j++)
    {
      let id = item[j].getAttribute("id");
      let path = item[j].getAttribute("path");
      let type = item[j].getAttribute("type");

      let pack = AssetPack.createXMLAssetPack(id,path,type);
      this.load.pack(id,null,pack);
    }


    // this.load.bitmapFont('pixelFont', 'assets/font/minecraft-font/minecraft-font.png', 'assets/font/minecraft-font/minecraft-font.xml');
    // this.load.image('mushroom', 'assets/images/sprite.png');
  }

  create () {
    this.state.start('MainMenu');
  }

}
