
import CMS from "../libs/cms/CMS";
import SoundManager from "../libs/sound/soundManager";

export default new class GameServices
{
    get CMS() { return this._cms; }
    get Sound() { return this._soundManager; }

    boot(game)
    {
        this.game = game;
        this._soundManager = new SoundManager(this.game);
        this._cms = new CMS(this.game);
    }

    setup()
    {

    }

}();
