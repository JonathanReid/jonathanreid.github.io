import Phaser from 'phaser'
import BaseState from '../libs/states/BaseState'
import GameServices from './GameServices';

export default class extends BaseState{
  init () {
    super.init();
    // scale the game 4x
    this.game.scale.scaleMode = Phaser.ScaleManager.USER_SCALE;
    this.game.scale.setUserScale(4, 4);

    // enable crisp rendering
    this.game.renderer.renderSession.roundPixels = true;
    Phaser.Canvas.setImageRenderingCrisp(this.game.canvas);
    this.game.stage.smoothed = false;

    // limit widow size - remove to let the game fill browser
    // the game scale is also affected by the game size in the constructor - see bolw
    this.game.scale.maxHeight = 558;
    this.game.scale.maxWidth = 800;

    // Phaser.Canvas.setSmoothingEnabled(this.game.context, false);

    this.stage.backgroundColor = '#ffffff';

    GameServices.boot(this.game);

    this.createServer();
  }

  createServer()
  {
    createConnection();
  }

  preload () {
    super.preload();

    this.load.image('loaderBg', './assets/images/loader-bg.png');
    this.load.image('loaderBar', './assets/images/loader-bar.png');
    this.load.xml('fileList','./assets/xml/fileList.xml');
  }

  update()
  {
    // super.update();
  }

  create () {
      this.state.start('Preloader')
  }

}
